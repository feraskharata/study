'''
# my code 
def task_view(request):
    url_tasks = "https://edu.ltomi.keenetic.pro/api/tasks/"
    data = None
    with urllib.request.urlopen(url_tasks) as url_:
        data = json.load(url_)
    
    task = data[0] # retrieve first task from API
    statement = task['condition']
    correct_answer = task['answer'] # retrieve correct answer from API
    
    if request.method == 'POST':
        user_answer = request.POST['answer'] # retrieve user's answer from form input
        if user_answer == correct_answer:
            feedback = 'Correct!'
        else:
            feedback = 'Incorrect. The correct answer is: ' + correct_answer
    else:
        feedback = ''
    
    message = Message.objects.create(
        user=request.user,
        room=room,
        body=statement
    )
    
    return render(request, 'task.html', {'message': message, 'feedback': feedback})

#   function to retrive  random questions (my code)

def chat_room(request):
    # Make a GET request to the API endpoint and retrieve the JSON response
    response = requests.get('https://edu.ltomi.keenetic.pro/api/tasks/')
    questions = response.json()

    # Select a random question from the response
    random_question = random.choice(questions)

    # Display the question in the chat room template
    return render(request, 'base/room_form.html', {'question': random_question})

#end function  
#  function to compare the student's answer (my code):



def check_answer(request):
    # Retrieve the student's answer from the form submission
    student_answer = request.POST['answer']

    # Retrieve the correct answer from the API
    question_id = request.POST['question_id']
    response = requests.get(f'https://edu.ltomi.keenetic.pro/api/tasks/{question_id}')
    question = response.json()
    correct_answer = question['correct_answer']

    # Compare the student's answer to the correct answer and return a JSON response
    if student_answer == correct_answer:

        # Store the answer in the database
        # ...

        # Return a success response
        return JsonResponse({'success': True})
    else:
        # Store the answer in the database
        # ...

        # Return an error response
        return JsonResponse({'success': False, 'correct_answer': correct_answer})
    
'''
 # display the tasks with the same activity to the user:
 '''
   url = "https://edu.ltomi.keenetic.pro/api/tasks/"
 data = None
 with urllib.request.urlopen(url) as url:
     data = json.load(url)
     activity_id = "f65534ed-c206-46d0-a129-b0c0bfccd649"
     tasks_with_activity = []
     for task in data:
        if activity_id in task['activity']:
            tasks_with_activity.append(task)
 
  # Render the tasks to a template
  context = {'tasks': tasks_with_activity}
  return render(request, 'task_list.html', context)
'''